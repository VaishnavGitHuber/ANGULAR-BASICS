import { Component } from '@angular/core';
import { RouterOutlet } from '@angular/router';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms'

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [CommonModule,FormsModule],
  templateUrl: './app.component.html',
  styleUrl: './app.component.css'
})

export class AppComponent {
  title = 'ETAPP';
  userName : string = "Vaishnav Krishna P";
  positiveText:string = "Every rupee tracked is a step toward smarter spending!"

  expenses = [
    { sino: 1, date: "2025-06-09", category: "Groceries", amount: 1200, notes: "Weekly vegetables and snacks" },
    { sino: 2, date: "2025-06-08", category: "Transport", amount: 300, notes: "Metro card recharge" },
    { sino: 3, date: "2025-06-07", category: "Dining", amount: 850, notes: "Dinner at restaurant" },
    { sino: 4, date: "2025-06-06", category: "Electricity", amount: 2400, notes: "Monthly bill payment" },
    { sino: 5, date: "2025-06-05", category: "Internet", amount: 999, notes: "Wi-Fi subscription" },
    { sino: 6, date: "2025-06-04", category: "Medical", amount: 150, notes: "Pharmacy purchase" },
    { sino: 7, date: "2025-06-03", category: "Stationery", amount: 220, notes: "Notebook and pens" },
    { sino: 8, date: "2025-06-02", category: "Recharge", amount: 299, notes: "Mobile recharge" },
    { sino: 9, date: "2025-06-01", category: "Subscriptions", amount: 499, notes: "Netflix monthly plan" },
    { sino: 10, date: "2025-05-31", category: "Gift", amount: 1500, notes: "Birthday present" }
  ];
  
  showSuccess() {
    alert("New Expense Added to the List");
  }
  
}
